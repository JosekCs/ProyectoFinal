package com.tema7.tema7ejemplo2.Adapter;

public class UsuarioAdapter {
    //Aun falta esta, no estamos seguros como implementarla al tener una herencia
}
